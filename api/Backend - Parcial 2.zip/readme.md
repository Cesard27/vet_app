### Instalation

1. Configure the database connection

2. execute:

```
npm install
```
3. run project

```
node index
```